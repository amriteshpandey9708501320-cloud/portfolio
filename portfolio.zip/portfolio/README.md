# Amritesh Kumar Pandey · Portfolio

A dark, cinematic personal portfolio built with **React + Vite + Tailwind CSS v4**, animated with **Motion**, **GSAP (ScrollTrigger)**, **Three.js** and **Lenis**.

## Run it

Requires Node 20.19+ (or 22.12+).

```bash
npm install
npm run dev        # http://localhost:5173
npm run build      # production build into dist/
npm run preview    # serve the production build locally
```

## 1. Fill in your details (5 minutes)

Everything lives in **`src/data/site.js`**. Search for `SET ME`.

| What | Where | Notes |
| --- | --- | --- |
| Email, GitHub, LinkedIn | `site.email`, `site.github`, `site.linkedin` | Until set, icons show dimmed and are not clickable (never a broken link). |
| Resume | replace `public/Amritesh_Kumar_Pandey_Resume.pdf` | The included file is a **starter** built only from the details you gave me. It has no contact info yet. Replace it with your own. |
| Projects | `projects` | The three cards are labelled **Example**. Replace them (see below). |
| Certificate verify links | `certificates[].verifyUrl` | Optional. Shows a "Verify" button in the viewer. The Udemy certificate shows a verification URL; paste it here once you've confirmed it opens. |

### Adding a real project

```js
{
  id: 'my-first-app',
  isExample: false,                       // removes the "Example" badge
  title: 'Weather Dashboard',
  description: 'What it does and what you learned.',
  tech: ['HTML', 'CSS', 'JavaScript'],
  github: 'https://github.com/you/weather-dashboard',   // button appears only if set
  live: 'https://you.github.io/weather-dashboard',      // button appears only if set
  image: '/images/weather.webp',          // put the screenshot in public/images/
  hue: 'blue',                            // used only when there is no image
}
```

When no card is marked as an example any more, the explanatory note above the grid disappears automatically.

### Adding certificates / learning entries / timeline items

Add objects to `certificates`, `learning` and `education` in the same file. Put new certificate images in `public/images/` (WebP recommended). The gallery, viewer and "View certificate" buttons update automatically.

## 2. Contact form setup

The form validates input, has a spam honeypot and clear success/error states. It needs a place to send messages. Pick **one**:

**Option A: Web3Forms (free, no server)**
1. Go to <https://web3forms.com>, enter your email and get an **Access Key**.
2. Paste it in `src/data/site.js` → `contactForm.web3formsKey`.

**Option B: Formspree (free tier)**
1. Create a form at <https://formspree.io> and copy its endpoint (`https://formspree.io/f/xxxxxxx`).
2. Paste it in `contactForm.formspreeEndpoint`.

**Fallback:** if neither is set but `site.email` is, submitting opens the visitor's email app with the message pre-filled. If nothing at all is configured, the form tells the visitor it isn't connected yet.

These keys/endpoints are designed to be public (they only allow *sending to you*). No secrets are stored in the project.

## 3. Deploy

Any static host works (Vercel, Netlify, Cloudflare Pages, GitHub Pages).
- Build command: `npm run build`   ·   Output directory: `dist`

After deploying, edit `index.html` and change `og:image` to the full URL (`https://your-domain.com/og-image.jpg`) so link previews on WhatsApp/LinkedIn show your photo.

## How the animation stack is used (and why)

| Tool | Used for |
| --- | --- |
| **Motion** | Entrance animations, staggered word reveals, hover/tap interactions, scroll reveals, loader exit, mobile menu, lightbox, magnetic buttons, custom cursor |
| **GSAP + ScrollTrigger** | Hero parallax, the scroll-drawn education timeline |
| **Lenis** | Smooth scrolling (synced with GSAP's ticker) |
| **Three.js** | Particle field + two wireframe shapes behind the page. **Desktop only**, lazy-loaded, paused when the tab is hidden |

**Not included on purpose:** *Spline* (needs an account and a scene URL, and would add weight without improving this design) and *Lottie* (needs animation JSON files; the loader and icons are done with CSS/SVG instead). Either can be added later without touching the rest.

## Performance, accessibility and safety notes

- Phones/tablets and anyone with **reduced motion** or **Data Saver** never download or run Three.js, Lenis or the custom cursor; the page falls back to CSS gradients and instant transitions.
- Images are WebP with responsive `srcset`; only the hero image loads eagerly, everything else is lazy.
- Semantic landmarks, skip link, visible focus states, keyboard-operable menu / skill cards / certificate viewer (Esc closes, ←/→ navigate, focus is trapped and restored).
- A React error boundary keeps the page usable if an optional feature (like WebGL) fails.

## Project structure

```
src/
  App.jsx                 page shell, Lenis + 3D gating
  data/site.js            ← all your content
  lib/                    gsap setup, scroll helpers, contact submit
  hooks/useMedia.js
  components/             Hero, About, Skills, Projects, Learning, Certificates,
                          Education, Contact, Navbar, Loader, Cursor, ParticleScene …
public/
  images/                 optimised portrait + certificate images
  Amritesh_Kumar_Pandey_Resume.pdf
```
