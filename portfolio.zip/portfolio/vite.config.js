import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import tailwindcss from '@tailwindcss/vite'

export default defineConfig({
  plugins: [react(), tailwindcss()],
  build: {
    target: 'es2020',
    // three.js is lazy-loaded (desktop only) so it is its own chunk
    chunkSizeWarningLimit: 700,
  },
})
