import { motion } from 'motion/react'
import { ArrowUpRight, Info } from 'lucide-react'
import { projects, projectsNote } from '../data/site'
import { FadeIn, SectionHeading } from './Reveal'
import { GithubIcon } from './icons'

const HUES = {
  blue: 'linear-gradient(135deg, #2a4fd6, #3d6bff 50%, #16224f)',
  violet: 'linear-gradient(135deg, #5b3bd6, #8b6bff 50%, #1d1647)',
  cyan: 'linear-gradient(135deg, #0f6fa8, #3fb4ff 50%, #0e2640)',
}

const trackPointer = (e) => {
  const r = e.currentTarget.getBoundingClientRect()
  e.currentTarget.style.setProperty('--mx', `${e.clientX - r.left}px`)
  e.currentTarget.style.setProperty('--my', `${e.clientY - r.top}px`)
}

/** Browser-window mock used when a project has no screenshot (decorative only). */
function PlaceholderShot({ hue }) {
  return (
    <div
      aria-hidden="true"
      className="relative aspect-[16/10] w-full overflow-hidden"
      style={{ background: HUES[hue] || HUES.blue }}
    >
      <div className="absolute inset-x-6 top-6 bottom-0 overflow-hidden rounded-t-xl border border-white/20 bg-[#070a17]/80 backdrop-blur-sm">
        <div className="flex items-center gap-1.5 border-b border-white/10 px-3 py-2.5">
          <span className="size-2 rounded-full bg-white/25" />
          <span className="size-2 rounded-full bg-white/25" />
          <span className="size-2 rounded-full bg-white/25" />
          <span className="ml-3 h-2 w-1/3 rounded bg-white/10" />
        </div>
        <div className="space-y-2.5 p-4">
          <div className="h-3 w-2/3 rounded bg-white/20" />
          <div className="h-2 w-full rounded bg-white/10" />
          <div className="h-2 w-5/6 rounded bg-white/10" />
          <div className="mt-4 grid grid-cols-3 gap-2.5">
            <div className="h-14 rounded-lg bg-white/10" />
            <div className="h-14 rounded-lg bg-white/10" />
            <div className="h-14 rounded-lg bg-white/10" />
          </div>
        </div>
      </div>
    </div>
  )
}

function ProjectCard({ project }) {
  return (
    <motion.article
      onPointerMove={trackPointer}
      whileHover={{ y: -6 }}
      transition={{ type: 'spring', stiffness: 300, damping: 22 }}
      className="glass spotlight group flex h-full flex-col overflow-hidden rounded-3xl"
    >
      <div className="relative overflow-hidden">
        <div className="transition-transform duration-700 ease-out group-hover:scale-[1.04]">
          {project.image ? (
            <img
              src={project.image}
              alt={`Screenshot of ${project.title}`}
              loading="lazy"
              decoding="async"
              className="aspect-[16/10] w-full object-cover"
            />
          ) : (
            <PlaceholderShot hue={project.hue} />
          )}
        </div>
        {project.isExample && (
          <span className="absolute left-4 top-4 rounded-full border border-white/25 bg-[#04050b]/70 px-3 py-1 font-mono text-[0.65rem] uppercase tracking-[0.14em] text-white backdrop-blur">
            Example
          </span>
        )}
      </div>

      <div className="flex flex-1 flex-col p-6">
        <h3 className="text-xl font-semibold text-white">{project.title}</h3>
        <p className="mt-3 flex-1 text-sm leading-relaxed text-white/60">{project.description}</p>

        <ul className="mt-5 flex flex-wrap gap-2" aria-label="Technologies used">
          {project.tech.map((t) => (
            <li key={t} className="chip !py-1 !text-[0.68rem]">
              {t}
            </li>
          ))}
        </ul>

        {(project.github || project.live) && (
          <div className="mt-6 flex flex-wrap gap-3">
            {project.github && (
              <a
                href={project.github}
                target="_blank"
                rel="noopener noreferrer"
                className="btn btn-ghost !px-4 !py-2.5 !text-sm"
              >
                <GithubIcon size={16} />
                GitHub
                <span className="sr-only"> (opens in a new tab)</span>
              </a>
            )}
            {project.live && (
              <a
                href={project.live}
                target="_blank"
                rel="noopener noreferrer"
                className="btn btn-primary !px-4 !py-2.5 !text-sm"
              >
                Live demo
                <ArrowUpRight size={16} aria-hidden="true" />
                <span className="sr-only"> (opens in a new tab)</span>
              </a>
            )}
          </div>
        )}
      </div>
    </motion.article>
  )
}

export default function Projects() {
  const hasExamples = projects.some((p) => p.isExample)

  return (
    <section id="projects" aria-label="Projects" className="section">
      <div className="container-x">
        <SectionHeading
          index="03"
          label="Projects"
          title="Things I'm building and learning from."
        />

        {hasExamples && (
          <FadeIn className="glass mb-10 flex gap-4 rounded-2xl p-5 text-sm text-white/70">
            <Info size={20} className="mt-0.5 shrink-0 text-electric" aria-hidden="true" />
            <p>{projectsNote}</p>
          </FadeIn>
        )}

        <ul className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {projects.map((project, i) => (
            <FadeIn as="li" key={project.id} delay={i * 0.08}>
              <ProjectCard project={project} />
            </FadeIn>
          ))}
        </ul>
      </div>
    </section>
  )
}
