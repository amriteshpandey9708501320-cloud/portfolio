import { useEffect, useRef } from 'react'
import { useReducedMotion } from 'motion/react'
import { GraduationCap, Award, Rocket } from 'lucide-react'
import { education } from '../data/site'
import { gsap, ScrollTrigger } from '../lib/gsap'
import { FadeIn, SectionHeading } from './Reveal'

const ICON = { current: GraduationCap, done: Award, upcoming: Rocket }

export default function Education() {
  const listRef = useRef(null)
  const reduced = useReducedMotion()

  // GSAP ScrollTrigger: the line draws as you scroll, items light up when reached
  useEffect(() => {
    const root = listRef.current
    if (!root) return
    const items = root.querySelectorAll('.tl-item')

    if (reduced) {
      items.forEach((el) => el.classList.add('is-active'))
      return
    }

    const ctx = gsap.context(() => {
      gsap.fromTo(
        '.tl-line-fill',
        { scaleY: 0 },
        {
          scaleY: 1,
          ease: 'none',
          scrollTrigger: { trigger: root, start: 'top 65%', end: 'bottom 65%', scrub: 0.6 },
        },
      )
      items.forEach((el) => {
        ScrollTrigger.create({
          trigger: el,
          start: 'top 68%',
          toggleClass: { targets: el, className: 'is-active' },
        })
      })
    }, root)

    return () => ctx.revert()
  }, [reduced])

  return (
    <section id="education" aria-label="Education" className="section">
      <div className="container-x">
        <SectionHeading
          index="06"
          label="Education"
          title="My academic and learning journey."
        />

        <ol ref={listRef} className="relative mx-auto max-w-3xl">
          {/* timeline rail */}
          <span
            aria-hidden="true"
            className="absolute bottom-2 left-[1.05rem] top-2 w-px bg-white/10 md:left-[1.2rem]"
          />
          <span
            aria-hidden="true"
            className="tl-line-fill tl-line absolute bottom-2 left-[1.05rem] top-2 w-px md:left-[1.2rem]"
            style={{ background: 'linear-gradient(180deg, #4f8bff, #8b6bff)' }}
          />

          {education.map((item, i) => {
            const Icon = ICON[item.state] || GraduationCap
            return (
              <li key={item.id} className="tl-item relative pb-12 pl-14 last:pb-0 md:pl-16">
                <span
                  aria-hidden="true"
                  className="tl-dot absolute left-0 top-1 grid size-[2.15rem] place-items-center rounded-full md:size-[2.4rem]"
                >
                  <Icon size={16} className="text-white" />
                </span>
                <FadeIn delay={i * 0.04} y={16}>
                  <div className="tl-card glass rounded-3xl p-6 md:p-7">
                    <p className="eyebrow !text-electric">{item.period}</p>
                    <h3 className="mt-2 text-xl font-semibold text-white">{item.title}</h3>
                    <p className="mt-1 text-sm text-white/55">{item.org}</p>
                    <p className="mt-4 text-sm leading-relaxed text-white/65">{item.text}</p>
                  </div>
                </FadeIn>
              </li>
            )
          })}
        </ol>
      </div>
    </section>
  )
}
