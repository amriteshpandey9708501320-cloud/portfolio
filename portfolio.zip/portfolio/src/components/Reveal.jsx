import { motion, useReducedMotion } from 'motion/react'

const EASE = [0.16, 1, 0.3, 1]

/**
 * Staggered word-by-word text reveal.
 *  - `play` undefined → plays when scrolled into view
 *  - `play` boolean   → controlled (e.g. wait for the loading screen)
 *  - `highlightFrom`  → word index from which the gradient is applied
 */
export function WordReveal({
  text,
  as = 'span',
  className = '',
  delay = 0,
  stagger = 0.07,
  play,
  highlightFrom = null,
}) {
  const reduced = useReducedMotion()
  const Tag = motion[as] || motion.span

  if (reduced) {
    const Plain = as
    return (
      <Plain className={className}>
        {highlightFrom === null ? (
          text
        ) : (
          <>
            {text.split(' ').slice(0, highlightFrom).join(' ')}{' '}
            <span className="text-gradient">{text.split(' ').slice(highlightFrom).join(' ')}</span>
          </>
        )}
      </Plain>
    )
  }

  const words = text.split(' ')
  const trigger =
    play === undefined
      ? { initial: 'hidden', whileInView: 'show', viewport: { once: true, margin: '-10% 0px' } }
      : { initial: 'hidden', animate: play ? 'show' : 'hidden' }

  return (
    <Tag
      className={className}
      variants={{ hidden: {}, show: { transition: { staggerChildren: stagger, delayChildren: delay } } }}
      {...trigger}
    >
      <span className="sr-only">{text}</span>
      {words.map((word, i) => (
        <span
          key={`${word}-${i}`}
          aria-hidden="true"
          className="inline-block overflow-hidden align-bottom"
          style={{ paddingBottom: '0.14em', marginBottom: '-0.14em' }}
        >
          <motion.span
            className={`inline-block ${highlightFrom !== null && i >= highlightFrom ? 'text-gradient' : ''}`}
            variants={{
              hidden: { y: '115%' },
              show: { y: 0, transition: { duration: 0.85, ease: EASE } },
            }}
          >
            {word}
            {i < words.length - 1 ? ' ' : ''}
          </motion.span>
        </span>
      ))}
    </Tag>
  )
}

/** Fade + rise when scrolled into view. */
export function FadeIn({ children, className = '', delay = 0, y = 24, as = 'div', ...rest }) {
  const reduced = useReducedMotion()
  const Tag = motion[as] || motion.div
  if (reduced) {
    const Plain = as
    return (
      <Plain className={className} {...rest}>
        {children}
      </Plain>
    )
  }
  return (
    <Tag
      className={className}
      initial={{ opacity: 0, y }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: '-8% 0px' }}
      transition={{ duration: 0.8, delay, ease: EASE }}
      {...rest}
    >
      {children}
    </Tag>
  )
}

/** Consistent section heading: numbered eyebrow + animated title + optional intro. */
export function SectionHeading({ index, label, title, description, className = '' }) {
  return (
    <div className={`mb-14 max-w-2xl md:mb-20 ${className}`}>
      <FadeIn y={12}>
        <p className="eyebrow mb-5 flex items-center gap-3">
          <span className="text-white/40">{index}</span>
          <span className="h-px w-10 bg-white/20" aria-hidden="true" />
          <span>{label}</span>
        </p>
      </FadeIn>
      <WordReveal
        as="h2"
        text={title}
        className="text-[clamp(2rem,4.6vw,3.4rem)] font-semibold leading-[1.05]"
      />
      {description ? (
        <FadeIn delay={0.15} y={14}>
          <p className="mt-6 text-base text-white/60 md:text-lg">{description}</p>
        </FadeIn>
      ) : null}
    </div>
  )
}
