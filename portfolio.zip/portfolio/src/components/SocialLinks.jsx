import { site } from '../data/site'
import { GithubIcon, LinkedinIcon } from './icons'

/**
 * Renders a real link when the URL is set in src/data/site.js.
 * Until then it renders a dimmed, non-clickable icon (never a broken link).
 */
function SocialLink({ href, label, children }) {
  const cls =
    'grid size-11 place-items-center rounded-full border border-white/12 bg-white/[0.04] transition-all'
  if (!href) {
    return (
      <span
        className={`${cls} cursor-not-allowed text-white/25`}
        role="img"
        aria-label={`${label} (link not set yet)`}
        title={`Add your ${label} URL in src/data/site.js`}
      >
        {children}
      </span>
    )
  }
  return (
    <a
      href={href}
      target="_blank"
      rel="noopener noreferrer"
      aria-label={label}
      className={`${cls} text-white/75 hover:-translate-y-0.5 hover:border-white/30 hover:bg-white/10 hover:text-white`}
    >
      {children}
    </a>
  )
}

export default function SocialLinks({ className = '' }) {
  return (
    <div className={`flex items-center gap-3 ${className}`}>
      <SocialLink href={site.github} label="GitHub">
        <GithubIcon size={19} />
      </SocialLink>
      <SocialLink href={site.linkedin} label="LinkedIn">
        <LinkedinIcon size={18} />
      </SocialLink>
    </div>
  )
}
