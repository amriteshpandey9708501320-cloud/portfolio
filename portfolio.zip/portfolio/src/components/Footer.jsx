import { site } from '../data/site'
import SocialLinks from './SocialLinks'

export default function Footer() {
  return (
    <footer className="relative z-10 border-t border-white/10 py-10">
      <div className="container-x flex flex-col items-center justify-between gap-6 text-sm text-white/45 md:flex-row">
        <div className="text-center md:text-left">
          <p>
            © {new Date().getFullYear()} {site.name}. All rights reserved.
          </p>
          <p className="mt-1 text-xs text-white/30">
            Built with React, Vite, Tailwind CSS, Motion, GSAP, Three.js and Lenis.
          </p>
        </div>
        <SocialLinks />
      </div>
    </footer>
  )
}
