import { motion, useScroll, useSpring } from 'motion/react'

export default function ScrollProgress() {
  const { scrollYProgress } = useScroll()
  const scaleX = useSpring(scrollYProgress, { stiffness: 140, damping: 30, restDelta: 0.001 })

  return (
    <motion.div
      aria-hidden="true"
      className="progress-bar fixed left-0 top-0 z-[60] h-[2px] w-full origin-left"
      style={{ scaleX }}
    />
  )
}
