import { useState } from 'react'
import { AnimatePresence, motion } from 'motion/react'
import { Braces, Check, Code, Cpu, GitBranch, Layers, Palette, Plus, Sparkles, Terminal } from 'lucide-react'
import { learningAreas, skills } from '../data/site'
import { FadeIn, SectionHeading } from './Reveal'

const ICONS = { Code, Palette, Braces, Cpu, Sparkles, Terminal, GitBranch, Layers }

// Moves the CSS spotlight to the pointer (see .spotlight in index.css)
const trackPointer = (e) => {
  const r = e.currentTarget.getBoundingClientRect()
  e.currentTarget.style.setProperty('--mx', `${e.clientX - r.left}px`)
  e.currentTarget.style.setProperty('--my', `${e.clientY - r.top}px`)
}

function SkillCard({ skill, open, onToggle }) {
  const Icon = ICONS[skill.icon] || Code
  const panelId = `skill-${skill.id}`

  return (
    <button
      type="button"
      onClick={onToggle}
      onPointerMove={trackPointer}
      aria-expanded={open}
      aria-controls={panelId}
      className="glass spotlight group block w-full rounded-3xl p-6 text-left transition-transform duration-300 hover:-translate-y-1"
    >
      <span className="flex items-start justify-between">
        <span className="grid size-12 place-items-center rounded-2xl border border-white/10 bg-electric/10 text-electric transition-colors group-hover:bg-electric/20">
          <Icon size={22} aria-hidden="true" />
        </span>
        <span
          className={`grid size-8 place-items-center rounded-full border border-white/10 text-white/60 transition-transform duration-300 ${
            open ? 'rotate-45' : ''
          }`}
          aria-hidden="true"
        >
          <Plus size={16} />
        </span>
      </span>

      <span className="mt-6 block font-display text-2xl font-semibold text-white">{skill.name}</span>
      <span className="chip mt-3 !py-1 !text-[0.68rem]">{skill.status}</span>
      <span className="mt-4 block text-sm leading-relaxed text-white/60">{skill.blurb}</span>

      <AnimatePresence initial={false}>
        {open && (
          <motion.span
            id={panelId}
            className="block overflow-hidden"
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.35, ease: [0.16, 1, 0.3, 1] }}
          >
            <span className="mt-5 block space-y-2.5 border-t border-white/10 pt-5">
              {skill.points.map((p) => (
                <span key={p} className="flex items-start gap-2.5 text-sm text-white/75">
                  <Check size={15} className="mt-0.5 shrink-0 text-electric" aria-hidden="true" />
                  {p}
                </span>
              ))}
            </span>
          </motion.span>
        )}
      </AnimatePresence>
    </button>
  )
}

export default function Skills() {
  const [openId, setOpenId] = useState(null)

  return (
    <section id="skills" aria-label="Technical skills" className="section">
      <div className="container-x">
        <SectionHeading
          index="02"
          label="Technical skills"
          title="The foundation I'm building on."
          description="These are the technologies I actively practice. Select a card to see what I'm working on with each."
        />

        <div className="grid items-start gap-5 sm:grid-cols-2 lg:grid-cols-4">
          {skills.map((skill, i) => (
            <FadeIn key={skill.id} delay={i * 0.07}>
              <SkillCard
                skill={skill}
                open={openId === skill.id}
                onToggle={() => setOpenId((cur) => (cur === skill.id ? null : skill.id))}
              />
            </FadeIn>
          ))}
        </div>

        <div className="mt-20">
          <FadeIn>
            <h3 className="eyebrow mb-6 !text-iris">Currently learning</h3>
          </FadeIn>
          <ul className="grid gap-4 sm:grid-cols-2">
            {learningAreas.map((area, i) => {
              const Icon = ICONS[area.icon] || Sparkles
              return (
                <FadeIn as="li" key={area.id} delay={i * 0.06}>
                  <div
                    onPointerMove={trackPointer}
                    className="glass spotlight flex h-full gap-5 rounded-3xl p-6"
                  >
                    <span className="grid size-11 shrink-0 place-items-center rounded-2xl border border-white/10 bg-iris/10 text-iris">
                      <Icon size={20} aria-hidden="true" />
                    </span>
                    <div>
                      <div className="flex flex-wrap items-center gap-3">
                        <h4 className="text-lg font-semibold text-white">{area.name}</h4>
                        <span className="rounded-full border border-iris/30 bg-iris/10 px-2.5 py-0.5 font-mono text-[0.65rem] uppercase tracking-wider text-iris">
                          {area.status}
                        </span>
                      </div>
                      <p className="mt-2 text-sm leading-relaxed text-white/60">{area.text}</p>
                    </div>
                  </div>
                </FadeIn>
              )
            })}
          </ul>
        </div>
      </div>
    </section>
  )
}
