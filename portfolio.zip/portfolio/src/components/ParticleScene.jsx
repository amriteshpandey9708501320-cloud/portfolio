import { useEffect, useRef } from 'react'
import * as THREE from 'three'

/**
 * Subtle interactive 3D background: a particle field plus two slow wireframe shapes.
 * - Only mounted on desktop-class screens without reduced-motion (see App.jsx),
 *   and lazy-loaded so phones never download three.js.
 * - Pauses when the tab is hidden, caps pixel ratio, disposes everything on unmount.
 */
export default function ParticleScene() {
  const mountRef = useRef(null)

  useEffect(() => {
    const mount = mountRef.current
    if (!mount) return

    let renderer
    try {
      renderer = new THREE.WebGLRenderer({ alpha: true, antialias: false, powerPreference: 'low-power' })
    } catch {
      return // WebGL unavailable: the CSS backdrop is still there
    }
    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 1.5))
    renderer.setSize(window.innerWidth, window.innerHeight)
    renderer.setClearColor(0x000000, 0)
    mount.appendChild(renderer.domElement)

    const scene = new THREE.Scene()
    const camera = new THREE.PerspectiveCamera(60, window.innerWidth / window.innerHeight, 0.1, 100)
    camera.position.z = 9

    // Soft round sprite so points look like glowing dots, not squares
    const sprite = (() => {
      const c = document.createElement('canvas')
      c.width = c.height = 64
      const g = c.getContext('2d')
      const grad = g.createRadialGradient(32, 32, 0, 32, 32, 32)
      grad.addColorStop(0, 'rgba(255,255,255,1)')
      grad.addColorStop(0.35, 'rgba(255,255,255,0.45)')
      grad.addColorStop(1, 'rgba(255,255,255,0)')
      g.fillStyle = grad
      g.fillRect(0, 0, 64, 64)
      return new THREE.CanvasTexture(c)
    })()

    const makeField = (count, color, size, spread) => {
      const positions = new Float32Array(count * 3)
      for (let i = 0; i < count; i++) {
        positions[i * 3] = (Math.random() - 0.5) * spread * 2
        positions[i * 3 + 1] = (Math.random() - 0.5) * spread
        positions[i * 3 + 2] = (Math.random() - 0.5) * spread
      }
      const geo = new THREE.BufferGeometry()
      geo.setAttribute('position', new THREE.BufferAttribute(positions, 3))
      const mat = new THREE.PointsMaterial({
        color,
        size,
        map: sprite,
        transparent: true,
        opacity: 0.8,
        depthWrite: false,
        sizeAttenuation: true,
        blending: THREE.AdditiveBlending,
      })
      return new THREE.Points(geo, mat)
    }

    const group = new THREE.Group()
    const blue = makeField(900, 0x4f8bff, 0.09, 20)
    const violet = makeField(450, 0x8b6bff, 0.11, 20)
    group.add(blue, violet)

    const shapeMat = (color) =>
      new THREE.MeshBasicMaterial({ color, wireframe: true, transparent: true, opacity: 0.16 })
    const ico = new THREE.Mesh(new THREE.IcosahedronGeometry(1.5, 1), shapeMat(0x4f8bff))
    ico.position.set(6.2, 1.6, -3)
    const octa = new THREE.Mesh(new THREE.OctahedronGeometry(1.1, 0), shapeMat(0x8b6bff))
    octa.position.set(-6.4, -2.4, -2)
    group.add(ico, octa)
    scene.add(group)

    // Pointer parallax + scroll depth
    const target = { x: 0, y: 0 }
    const onPointer = (e) => {
      target.x = (e.clientX / window.innerWidth - 0.5) * 2
      target.y = (e.clientY / window.innerHeight - 0.5) * 2
    }
    window.addEventListener('pointermove', onPointer, { passive: true })

    const onResize = () => {
      camera.aspect = window.innerWidth / window.innerHeight
      camera.updateProjectionMatrix()
      renderer.setSize(window.innerWidth, window.innerHeight)
    }
    window.addEventListener('resize', onResize)

    let raf = 0
    let running = true
    const clock = new THREE.Clock()
    const render = () => {
      if (!running) return
      const t = clock.getElapsedTime()
      const scrollDepth = window.scrollY / Math.max(1, document.body.scrollHeight - window.innerHeight)

      blue.rotation.y = t * 0.02
      violet.rotation.y = -t * 0.03
      ico.rotation.x = t * 0.1
      ico.rotation.y = t * 0.14
      octa.rotation.y = -t * 0.12
      octa.rotation.z = t * 0.08

      group.rotation.y += (target.x * 0.12 - group.rotation.y) * 0.04
      group.rotation.x += (target.y * 0.06 - group.rotation.x) * 0.04
      camera.position.y += (-scrollDepth * 5 - camera.position.y) * 0.05

      renderer.render(scene, camera)
      raf = requestAnimationFrame(render)
    }
    render()

    const onVisibility = () => {
      if (document.hidden) {
        running = false
        cancelAnimationFrame(raf)
      } else if (!running) {
        running = true
        clock.getDelta()
        render()
      }
    }
    document.addEventListener('visibilitychange', onVisibility)

    return () => {
      running = false
      cancelAnimationFrame(raf)
      window.removeEventListener('pointermove', onPointer)
      window.removeEventListener('resize', onResize)
      document.removeEventListener('visibilitychange', onVisibility)
      scene.traverse((obj) => {
        if (obj.geometry) obj.geometry.dispose()
        if (obj.material) obj.material.dispose()
      })
      sprite.dispose()
      renderer.dispose()
      if (renderer.domElement.parentNode === mount) mount.removeChild(renderer.domElement)
    }
  }, [])

  return <div ref={mountRef} aria-hidden="true" className="pointer-events-none fixed inset-0 z-[1]" />
}
