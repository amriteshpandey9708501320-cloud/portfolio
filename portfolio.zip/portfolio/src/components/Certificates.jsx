import { useCallback, useEffect, useRef, useState } from 'react'
import { createPortal } from 'react-dom'
import { AnimatePresence, motion } from 'motion/react'
import { ChevronLeft, ChevronRight, ExternalLink, Maximize2, X } from 'lucide-react'
import { certificates } from '../data/site'
import { lockScroll, unlockScroll } from '../lib/scroll'
import { FadeIn, SectionHeading } from './Reveal'

function Lightbox({ index, onClose, onNavigate }) {
  const cert = certificates[index]
  const dialogRef = useRef(null)
  const closeRef = useRef(null)
  const count = certificates.length

  // Lock page scroll while open, remember + restore focus
  useEffect(() => {
    const previous = document.activeElement
    lockScroll()
    closeRef.current?.focus()
    return () => {
      unlockScroll()
      if (previous instanceof HTMLElement) previous.focus()
    }
  }, [])

  // Keyboard: Esc closes, arrows navigate, Tab stays inside the dialog
  useEffect(() => {
    const onKey = (e) => {
      if (e.key === 'Escape') onClose()
      else if (e.key === 'ArrowRight') onNavigate(1)
      else if (e.key === 'ArrowLeft') onNavigate(-1)
      else if (e.key === 'Tab' && dialogRef.current) {
        const focusables = dialogRef.current.querySelectorAll('button, a[href]')
        if (!focusables.length) return
        const first = focusables[0]
        const last = focusables[focusables.length - 1]
        if (e.shiftKey && document.activeElement === first) {
          e.preventDefault()
          last.focus()
        } else if (!e.shiftKey && document.activeElement === last) {
          e.preventDefault()
          first.focus()
        }
      }
    }
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [onClose, onNavigate])

  return (
    <motion.div
      className="fixed inset-0 z-[120] grid place-items-center p-4 md:p-8"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.25 }}
    >
      <div
        className="absolute inset-0 bg-[#02030a]/90 backdrop-blur-md"
        onClick={onClose}
        aria-hidden="true"
      />

      <div
        ref={dialogRef}
        role="dialog"
        aria-modal="true"
        aria-label={`Certificate: ${cert.title}`}
        className="relative flex max-h-full w-full max-w-4xl flex-col"
      >
        <div className="mb-3 flex items-start justify-between gap-4">
          <div>
            <p className="font-display text-lg font-semibold text-white md:text-xl">{cert.title}</p>
            <p className="text-sm text-white/55">
              {cert.issuer} · {cert.date}
            </p>
          </div>
          <button
            ref={closeRef}
            type="button"
            onClick={onClose}
            aria-label="Close certificate viewer"
            className="glass grid size-10 shrink-0 place-items-center rounded-full text-white"
          >
            <X size={20} aria-hidden="true" />
          </button>
        </div>

        <div className="relative min-h-0 overflow-hidden rounded-2xl border border-white/10 bg-ink-900">
          <AnimatePresence mode="wait" initial={false}>
            <motion.img
              key={cert.id}
              src={cert.full}
              width={cert.width}
              height={cert.height}
              alt={`${cert.title}, certificate from ${cert.issuer}, issued ${cert.date}`}
              className="mx-auto max-h-[68vh] w-auto max-w-full object-contain"
              initial={{ opacity: 0, scale: 0.98 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.25 }}
            />
          </AnimatePresence>
        </div>

        <div className="mt-4 flex flex-wrap items-center justify-between gap-3">
          <p className="text-sm text-white/55">{cert.summary}</p>
          <div className="flex items-center gap-2">
            {cert.verifyUrl && (
              <a
                href={cert.verifyUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="btn btn-ghost !px-4 !py-2.5 !text-sm"
              >
                Verify
                <ExternalLink size={15} aria-hidden="true" />
                <span className="sr-only"> (opens in a new tab)</span>
              </a>
            )}
            {count > 1 && (
              <>
                <button
                  type="button"
                  onClick={() => onNavigate(-1)}
                  aria-label="Previous certificate"
                  className="glass grid size-10 place-items-center rounded-full text-white"
                >
                  <ChevronLeft size={20} aria-hidden="true" />
                </button>
                <span className="font-mono text-xs tabular-nums text-white/50" aria-live="polite">
                  {index + 1} / {count}
                </span>
                <button
                  type="button"
                  onClick={() => onNavigate(1)}
                  aria-label="Next certificate"
                  className="glass grid size-10 place-items-center rounded-full text-white"
                >
                  <ChevronRight size={20} aria-hidden="true" />
                </button>
              </>
            )}
          </div>
        </div>
      </div>
    </motion.div>
  )
}

export default function Certificates() {
  const [openIndex, setOpenIndex] = useState(null)

  const close = useCallback(() => setOpenIndex(null), [])
  const navigate = useCallback(
    (dir) => setOpenIndex((i) => (i === null ? i : (i + dir + certificates.length) % certificates.length)),
    [],
  )

  // Lets the "View certificate" buttons in the Learning section open the viewer
  useEffect(() => {
    const onOpen = (e) => {
      const idx = certificates.findIndex((c) => c.id === e.detail)
      if (idx >= 0) setOpenIndex(idx)
    }
    window.addEventListener('open-certificate', onOpen)
    return () => window.removeEventListener('open-certificate', onOpen)
  }, [])

  return (
    <section id="certificates" aria-label="Certificates" className="section">
      <div className="container-x">
        <SectionHeading
          index="05"
          label="Certificates"
          title="Proof of the work I've put in."
          description="Select a certificate to view it full size."
        />

        <ul className="grid gap-6 md:grid-cols-2">
          {certificates.map((cert, i) => (
            <FadeIn as="li" key={cert.id} delay={i * 0.1}>
              <button
                type="button"
                onClick={() => setOpenIndex(i)}
                aria-haspopup="dialog"
                aria-label={`View certificate: ${cert.title}`}
                className="glass group block w-full overflow-hidden rounded-3xl text-left"
              >
                <div className="relative overflow-hidden bg-ink-900">
                  <img
                    src={cert.thumb}
                    srcSet={`${cert.thumb} 540w, ${cert.full} 1080w`}
                    sizes="(min-width: 768px) 36rem, 92vw"
                    width={cert.width}
                    height={cert.height}
                    alt={`Preview of the ${cert.title} certificate from ${cert.issuer}`}
                    loading="lazy"
                    decoding="async"
                    className="aspect-[4/3] w-full object-cover object-top transition-transform duration-700 ease-out group-hover:scale-[1.04]"
                  />
                  <span className="absolute inset-0 grid place-items-center bg-[#04050b]/55 opacity-0 transition-opacity duration-300 group-hover:opacity-100 group-focus-visible:opacity-100">
                    <span className="btn btn-primary !px-5 !py-3 !text-sm">
                      <Maximize2 size={16} aria-hidden="true" />
                      View full size
                    </span>
                  </span>
                </div>
                <div className="p-6">
                  <p className="eyebrow !text-white/45">
                    {cert.issuer} · {cert.date}
                  </p>
                  <h3 className="mt-2 text-lg font-semibold leading-snug text-white">{cert.title}</h3>
                  <p className="mt-1 text-sm text-white/55">{cert.summary}</p>
                </div>
              </button>
            </FadeIn>
          ))}
        </ul>
      </div>

      {/* Portal: keeps the viewer above the fixed navbar regardless of stacking contexts */}
      {createPortal(
        <AnimatePresence>
          {openIndex !== null && <Lightbox index={openIndex} onClose={close} onNavigate={navigate} />}
        </AnimatePresence>,
        document.body,
      )}
    </section>
  )
}
