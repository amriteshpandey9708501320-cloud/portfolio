import { useEffect, useRef } from 'react'
import { motion, useMotionValue, useReducedMotion, useSpring, useTransform } from 'motion/react'
import { ArrowDown, Download, MapPin, Sparkles } from 'lucide-react'
import { site } from '../data/site'
import { gsap } from '../lib/gsap'
import { scrollToId } from '../lib/scroll'
import { useMedia } from '../hooks/useMedia'
import { WordReveal } from './Reveal'
import Magnetic from './Magnetic'
import SocialLinks from './SocialLinks'

const EASE = [0.16, 1, 0.3, 1]

export default function Hero({ ready }) {
  const rootRef = useRef(null)
  const reduced = useReducedMotion()
  const fine = useMedia('(hover: hover) and (pointer: fine)')

  // Subtle 3D tilt of the portrait on desktop
  const px = useMotionValue(0)
  const py = useMotionValue(0)
  const sx = useSpring(px, { stiffness: 120, damping: 18 })
  const sy = useSpring(py, { stiffness: 120, damping: 18 })
  const rotateY = useTransform(sx, [-0.5, 0.5], [-7, 7])
  const rotateX = useTransform(sy, [-0.5, 0.5], [6, -6])

  const onPhotoMove = (e) => {
    if (reduced || !fine) return
    const r = e.currentTarget.getBoundingClientRect()
    px.set((e.clientX - r.left) / r.width - 0.5)
    py.set((e.clientY - r.top) / r.height - 0.5)
  }
  const onPhotoLeave = () => {
    px.set(0)
    py.set(0)
  }

  // GSAP ScrollTrigger: gentle parallax as the hero scrolls away
  useEffect(() => {
    if (reduced) return
    const ctx = gsap.context(() => {
      const st = { trigger: rootRef.current, start: 'top top', end: 'bottom top', scrub: true }
      gsap.to('[data-hero-photo]', { yPercent: 7, ease: 'none', scrollTrigger: st })
      gsap.to('[data-hero-copy]', { yPercent: -5, opacity: 0.15, ease: 'none', scrollTrigger: st })
    }, rootRef)
    return () => ctx.revert()
  }, [reduced])

  return (
    <section
      id="home"
      ref={rootRef}
      aria-label="Introduction"
      className="relative flex min-h-[100svh] items-center overflow-hidden pb-16 pt-28 md:pt-24"
    >
      <div className="bg-grid pointer-events-none absolute inset-0" aria-hidden="true" />

      <div className="container-x relative z-10 grid items-center gap-14 lg:grid-cols-12 lg:gap-10">
        {/* ── Copy ── */}
        <div data-hero-copy className="order-2 lg:order-1 lg:col-span-7">
          <motion.p
            className="chip mb-7"
            initial={{ opacity: 0, y: 14 }}
            animate={ready ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.7, ease: EASE, delay: 0.1 }}
          >
            <span className="pulse-dot inline-block size-2 rounded-full bg-electric" aria-hidden="true" />
            Computer Science Engineering · {site.location}
          </motion.p>

          <h1 className="font-display text-[clamp(2.4rem,6vw,4.9rem)] font-semibold uppercase leading-[0.98] tracking-tight text-white">
            <WordReveal text={site.name} play={ready} delay={0.2} stagger={0.1} />
          </h1>

          <p className="mt-6 font-display text-[clamp(1.35rem,2.6vw,2.1rem)] font-medium leading-tight text-white/90">
            <WordReveal
              text={site.headline}
              play={ready}
              delay={0.6}
              stagger={0.07}
              highlightFrom={site.headlineHighlightFrom}
            />
          </p>

          <motion.p
            className="mt-5 font-mono text-xs uppercase tracking-[0.16em] text-electric/90 md:text-sm"
            initial={{ opacity: 0, y: 12 }}
            animate={ready ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.7, ease: EASE, delay: 1.0 }}
          >
            {site.subtitle}
          </motion.p>

          <motion.p
            className="mt-6 max-w-xl text-base leading-relaxed text-white/60 md:text-lg"
            initial={{ opacity: 0, y: 12 }}
            animate={ready ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.7, ease: EASE, delay: 1.1 }}
          >
            {site.intro}
          </motion.p>

          <motion.div
            className="mt-9 flex flex-wrap items-center gap-4"
            initial={{ opacity: 0, y: 12 }}
            animate={ready ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.7, ease: EASE, delay: 1.25 }}
          >
            <Magnetic>
              <a
                href="#projects"
                className="btn btn-primary"
                onClick={(e) => {
                  e.preventDefault()
                  scrollToId('projects')
                }}
              >
                View My Projects
                <ArrowDown size={18} aria-hidden="true" />
              </a>
            </Magnetic>
            <Magnetic>
              <a href={site.resume} download className="btn btn-ghost">
                <Download size={18} aria-hidden="true" />
                Download Resume
              </a>
            </Magnetic>
            <SocialLinks className="ml-1" />
          </motion.div>
        </div>

        {/* ── Portrait ── */}
        <div data-hero-photo className="order-1 mx-auto w-full max-w-[min(78vw,26rem)] lg:order-2 lg:col-span-5 lg:max-w-none">
          <motion.div
            className="relative mx-auto max-w-[26rem] lg:ml-auto"
            style={{ perspective: 1100 }}
            initial={{ opacity: 0, scale: 0.94, y: 30 }}
            animate={ready ? { opacity: 1, scale: 1, y: 0 } : {}}
            transition={{ duration: 1.1, ease: EASE, delay: 0.15 }}
          >
            {/* glow behind the frame */}
            <div
              aria-hidden="true"
              className="absolute -inset-6 -z-10 rounded-[3rem] opacity-70 blur-3xl"
              style={{ background: 'radial-gradient(circle at 30% 20%, rgb(79 139 255 / 0.45), rgb(139 107 255 / 0.3) 55%, transparent 75%)' }}
            />
            {/* offset outline */}
            <div
              aria-hidden="true"
              className="absolute inset-0 translate-x-3 translate-y-3 rounded-[2rem] border border-electric/30"
            />

            <motion.div
              onPointerMove={onPhotoMove}
              onPointerLeave={onPhotoLeave}
              style={{ rotateX, rotateY, transformStyle: 'preserve-3d' }}
              className="relative overflow-hidden rounded-[2rem] border border-white/15 bg-ink-800 shadow-[0_40px_90px_-30px_rgba(40,80,255,0.55)]"
            >
              <img
                src="/images/amritesh-900.webp"
                srcSet="/images/amritesh-480.webp 480w, /images/amritesh-900.webp 900w"
                sizes="(min-width: 1024px) 26rem, 78vw"
                width="900"
                height="1125"
                alt="Portrait of Amritesh Kumar Pandey seated at his desk"
                fetchPriority="high"
                decoding="async"
                className="aspect-[4/5] h-auto w-full object-cover"
              />
              {/* soft lighting + bottom fade */}
              <div
                aria-hidden="true"
                className="pointer-events-none absolute inset-0"
                style={{
                  background:
                    'linear-gradient(180deg, rgb(255 255 255 / 0.05), transparent 30%, rgb(4 5 11 / 0.55) 100%)',
                }}
              />
            </motion.div>

            <div className="glass float-slow absolute -left-3 bottom-10 flex items-center gap-2.5 rounded-2xl px-3.5 py-2.5 text-sm text-white md:-left-8">
              <MapPin size={16} className="text-electric" aria-hidden="true" />
              <span>Coimbatore, India</span>
            </div>
            <div className="glass float-slower absolute -right-2 top-10 flex items-center gap-2.5 rounded-2xl px-3.5 py-2.5 text-sm text-white md:-right-6">
              <Sparkles size={16} className="text-iris" aria-hidden="true" />
              <span>Learning every day</span>
            </div>
          </motion.div>
        </div>
      </div>

      {/* scroll cue */}
      <div className="pointer-events-none absolute bottom-6 left-1/2 hidden -translate-x-1/2 flex-col items-center gap-2 text-white/40 md:flex" aria-hidden="true">
        <span className="eyebrow !text-white/40 !tracking-[0.3em]">Scroll</span>
        <span className="relative block h-10 w-px overflow-hidden bg-white/15">
          <span
            className="absolute inset-0 bg-electric"
            style={{ animation: 'scroll-cue 1.8s ease-in-out infinite' }}
          />
        </span>
      </div>
    </section>
  )
}
