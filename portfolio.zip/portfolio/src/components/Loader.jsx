import { useEffect, useRef, useState } from 'react'
import { motion, useReducedMotion } from 'motion/react'

const easeOut = (t) => 1 - Math.pow(1 - t, 3)

export default function Loader({ onDone }) {
  const reduced = useReducedMotion()
  const [progress, setProgress] = useState(0)
  const doneRef = useRef(onDone)
  doneRef.current = onDone

  useEffect(() => {
    const duration = reduced ? 300 : 1500
    const start = performance.now()
    let raf
    let timer
    const tick = (now) => {
      const p = Math.min(1, (now - start) / duration)
      setProgress(Math.round(easeOut(p) * 100))
      if (p < 1) raf = requestAnimationFrame(tick)
      else timer = setTimeout(() => doneRef.current?.(), 220)
    }
    raf = requestAnimationFrame(tick)
    return () => {
      cancelAnimationFrame(raf)
      clearTimeout(timer)
    }
  }, [reduced])

  return (
    <motion.div
      className="fixed inset-0 z-[200] grid place-items-center bg-[#04050b]"
      initial={{ clipPath: 'inset(0 0 0% 0)' }}
      exit={{ clipPath: 'inset(0 0 100% 0)', transition: { duration: 0.9, ease: [0.76, 0, 0.24, 1] } }}
      role="status"
      aria-live="polite"
      aria-label="Loading portfolio"
    >
      <div className="w-[min(78vw,320px)] text-center">
        <motion.div
          initial={{ opacity: 0, y: 14 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, ease: [0.16, 1, 0.3, 1] }}
          className="font-display text-6xl font-semibold tracking-tight"
        >
          <span className="text-gradient">AP</span>
        </motion.div>
        <p className="eyebrow mt-4 !text-white/50">Amritesh Kumar Pandey</p>
        <div className="mt-8 h-px w-full overflow-hidden bg-white/10">
          <div
            className="progress-bar h-full origin-left"
            style={{ transform: `scaleX(${progress / 100})` }}
          />
        </div>
        <p className="mt-3 font-mono text-xs tabular-nums text-white/40">{progress}%</p>
      </div>
    </motion.div>
  )
}
