import { useEffect, useRef, useState } from 'react'
import { animate, useInView, useReducedMotion } from 'motion/react'
import { Target } from 'lucide-react'
import { about, learningAreas, skills, certificates } from '../data/site'
import { FadeIn, SectionHeading } from './Reveal'

function CountUp({ to, decimals = 0, suffix = '' }) {
  const ref = useRef(null)
  const inView = useInView(ref, { once: true, margin: '-15% 0px' })
  const reduced = useReducedMotion()
  const [value, setValue] = useState(0)

  useEffect(() => {
    if (!inView) return
    if (reduced) {
      setValue(to)
      return
    }
    const controls = animate(0, to, { duration: 1.6, ease: 'easeOut', onUpdate: setValue })
    return () => controls.stop()
  }, [inView, to, reduced])

  return (
    <span ref={ref} className="tabular-nums">
      {value.toFixed(decimals)}
      {suffix}
    </span>
  )
}

// Every number here is derived from the data in site.js, nothing hard-coded.
const stats = [
  { to: 30.5, decimals: 1, suffix: ' h', label: 'C++ course completed on Udemy' },
  { to: certificates.length, decimals: 0, suffix: '', label: 'Certificates earned' },
  {
    to: skills.length + learningAreas.length,
    decimals: 0,
    suffix: '',
    label: 'Skills & tools in my stack and learning list',
  },
]

export default function About() {
  return (
    <section id="about" aria-label="About me" className="section">
      <div className="container-x">
        <SectionHeading
          index="01"
          label="About me"
          title="A student who likes building things that work."
        />

        <div className="grid gap-12 lg:grid-cols-12 lg:gap-16">
          <div className="space-y-6 text-base leading-relaxed text-white/65 md:text-lg lg:col-span-7">
            {about.paragraphs.map((p, i) => (
              <FadeIn key={i} delay={i * 0.08}>
                <p>{p}</p>
              </FadeIn>
            ))}

            <FadeIn delay={0.2}>
              <p className="eyebrow mb-4 mt-10">Interests</p>
              <ul className="flex flex-wrap gap-2.5">
                {about.interests.map((item) => (
                  <li key={item} className="chip !text-[0.8rem]">
                    {item}
                  </li>
                ))}
              </ul>
            </FadeIn>
          </div>

          <div className="space-y-6 lg:col-span-5">
            <FadeIn className="glass rounded-3xl p-7">
              <p className="eyebrow mb-6">Learning journey</p>
              <ol className="space-y-6">
                {about.journey.map((s) => (
                  <li key={s.step} className="flex gap-5">
                    <span className="font-mono text-sm text-electric">{s.step}</span>
                    <div>
                      <h3 className="text-lg font-semibold text-white">{s.title}</h3>
                      <p className="mt-1 text-sm text-white/55">{s.text}</p>
                    </div>
                  </li>
                ))}
              </ol>
            </FadeIn>

            <FadeIn delay={0.1} className="glass flex gap-4 rounded-3xl p-7">
              <Target className="mt-1 shrink-0 text-iris" size={22} aria-hidden="true" />
              <div>
                <p className="eyebrow mb-2 !text-iris">Ambition</p>
                <p className="text-white/75">{about.ambition}</p>
              </div>
            </FadeIn>
          </div>
        </div>

        <dl className="mt-16 grid gap-4 sm:grid-cols-3">
          {stats.map((s, i) => (
            <FadeIn key={s.label} delay={i * 0.08} className="glass flex flex-col rounded-3xl p-7">
              <dt className="order-2 mt-2 text-sm text-white/55">{s.label}</dt>
              <dd className="font-display text-5xl font-semibold text-white">
                <CountUp to={s.to} decimals={s.decimals} suffix={s.suffix} />
              </dd>
            </FadeIn>
          ))}
        </dl>
      </div>
    </section>
  )
}
