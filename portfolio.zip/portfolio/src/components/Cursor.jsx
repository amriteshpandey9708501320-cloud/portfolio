import { useEffect, useState } from 'react'
import { motion, useMotionValue, useSpring } from 'motion/react'

/** Custom cursor. Only mounted on desktop-class pointers (see App.jsx). */
export default function Cursor() {
  const x = useMotionValue(-100)
  const y = useMotionValue(-100)
  const rx = useSpring(x, { stiffness: 190, damping: 24, mass: 0.4 })
  const ry = useSpring(y, { stiffness: 190, damping: 24, mass: 0.4 })
  const [mode, setMode] = useState('hidden') // 'default' | 'link' | 'text' | 'hidden'

  useEffect(() => {
    const root = document.documentElement
    root.classList.add('has-cursor')

    const move = (e) => {
      x.set(e.clientX)
      y.set(e.clientY)
      setMode((m) => (m === 'hidden' ? 'default' : m))
    }
    const over = (e) => {
      const t = e.target
      if (!(t instanceof Element)) return
      if (t.closest('input, textarea, select')) setMode('text')
      else if (t.closest('a, button, [role="button"], [data-cursor]')) setMode('link')
      else setMode('default')
    }
    const leave = () => setMode('hidden')

    window.addEventListener('pointermove', move, { passive: true })
    document.addEventListener('mouseover', over)
    root.addEventListener('mouseleave', leave)
    return () => {
      root.classList.remove('has-cursor')
      window.removeEventListener('pointermove', move)
      document.removeEventListener('mouseover', over)
      root.removeEventListener('mouseleave', leave)
    }
  }, [x, y])

  const hidden = mode === 'hidden' || mode === 'text'

  return (
    <>
      <motion.div
        aria-hidden="true"
        className="cursor-ring"
        style={{ x: rx, y: ry }}
        animate={{ scale: mode === 'link' ? 1.7 : 1, opacity: hidden ? 0 : 1 }}
        transition={{ duration: 0.2 }}
      />
      <motion.div
        aria-hidden="true"
        className="cursor-dot"
        style={{ x, y }}
        animate={{ opacity: hidden ? 0 : 1, scale: mode === 'link' ? 0.5 : 1 }}
        transition={{ duration: 0.15 }}
      />
    </>
  )
}
