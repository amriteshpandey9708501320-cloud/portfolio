import { useState } from 'react'
import { AlertCircle, CheckCircle2, Mail, Send } from 'lucide-react'
import { site } from '../data/site'
import { submitContact } from '../lib/submitContact'
import { FadeIn, SectionHeading } from './Reveal'
import Magnetic from './Magnetic'
import { GithubIcon, LinkedinIcon } from './icons'

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/

function ContactRow({ icon, label, value, href }) {
  const content = (
    <>
      <span className="grid size-11 shrink-0 place-items-center rounded-2xl border border-white/10 bg-white/5 text-electric">
        {icon}
      </span>
      <span className="min-w-0">
        <span className="eyebrow block !text-white/40">{label}</span>
        <span className={`block truncate ${href ? 'text-white' : 'text-white/35'}`}>
          {href ? value : 'Not added yet'}
        </span>
      </span>
    </>
  )
  const cls = 'glass flex items-center gap-4 rounded-2xl p-4'
  if (!href) {
    return (
      <div className={cls} title={`Add your ${label} in src/data/site.js`}>
        {content}
      </div>
    )
  }
  return (
    <a
      href={href}
      target={href.startsWith('mailto:') ? undefined : '_blank'}
      rel="noopener noreferrer"
      className={`${cls} transition-colors hover:border-white/25 hover:bg-white/[0.07]`}
    >
      {content}
    </a>
  )
}

export default function Contact() {
  const [values, setValues] = useState({ name: '', email: '', message: '', company: '' }) // company = honeypot
  const [errors, setErrors] = useState({})
  const [status, setStatus] = useState({ state: 'idle', message: '' })

  const onChange = (e) => {
    const { name, value } = e.target
    setValues((v) => ({ ...v, [name]: value }))
    if (errors[name]) setErrors((er) => ({ ...er, [name]: undefined }))
  }

  const validate = () => {
    const er = {}
    if (values.name.trim().length < 2) er.name = 'Please enter your name.'
    if (!EMAIL_RE.test(values.email.trim())) er.email = 'Please enter a valid email address.'
    if (values.message.trim().length < 10) er.message = 'Please write at least a short message (10+ characters).'
    return er
  }

  const onSubmit = async (e) => {
    e.preventDefault()
    if (values.company) return // bots fill the hidden field; silently ignore
    const er = validate()
    setErrors(er)
    if (Object.keys(er).length) return

    setStatus({ state: 'sending', message: '' })
    try {
      const mode = await submitContact({
        name: values.name.trim(),
        email: values.email.trim(),
        message: values.message.trim(),
      })
      setStatus({
        state: 'success',
        message:
          mode === 'mailto'
            ? 'Your email app should now be open with the message ready to send.'
            : "Thanks! Your message was sent. I'll get back to you soon.",
      })
      setValues({ name: '', email: '', message: '', company: '' })
    } catch (err) {
      setStatus({
        state: 'error',
        message:
          err.message === 'NOT_CONFIGURED'
            ? 'The contact form is not connected yet. Please reach out through the links on this page.'
            : 'Sorry, your message could not be sent. Please try again in a moment.',
      })
    }
  }

  const field =
    'w-full rounded-2xl border bg-white/[0.04] px-4 py-3.5 text-white placeholder:text-white/30 outline-none transition-colors focus:border-electric/70 focus:bg-white/[0.06]'

  return (
    <section id="contact" aria-label="Contact" className="section">
      <div className="container-x">
        <SectionHeading
          index="07"
          label="Contact"
          title="Let's talk about what's next."
          description="Have a question, an idea, or an opportunity to learn together? I'd love to hear from you."
        />

        <div className="grid gap-10 lg:grid-cols-12 lg:gap-14">
          <div className="space-y-4 lg:col-span-5">
            <FadeIn>
              <ContactRow
                icon={<Mail size={20} aria-hidden="true" />}
                label="Email"
                value={site.email}
                href={site.email ? `mailto:${site.email}` : ''}
              />
            </FadeIn>
            <FadeIn delay={0.07}>
              <ContactRow
                icon={<LinkedinIcon size={19} />}
                label="LinkedIn"
                value="Connect on LinkedIn"
                href={site.linkedin}
              />
            </FadeIn>
            <FadeIn delay={0.14}>
              <ContactRow
                icon={<GithubIcon size={20} />}
                label="GitHub"
                value="See my code on GitHub"
                href={site.github}
              />
            </FadeIn>
          </div>

          <FadeIn className="lg:col-span-7">
            <form onSubmit={onSubmit} noValidate className="glass rounded-3xl p-6 md:p-8">
              <div className="grid gap-5 md:grid-cols-2">
                <div>
                  <label htmlFor="name" className="mb-2 block text-sm text-white/70">
                    Name
                  </label>
                  <input
                    id="name"
                    name="name"
                    type="text"
                    autoComplete="name"
                    value={values.name}
                    onChange={onChange}
                    aria-invalid={Boolean(errors.name)}
                    aria-describedby={errors.name ? 'name-error' : undefined}
                    className={`${field} ${errors.name ? 'border-red-400/70' : 'border-white/10'}`}
                    placeholder="Your name"
                  />
                  {errors.name && (
                    <p id="name-error" className="mt-2 text-sm text-red-300">
                      {errors.name}
                    </p>
                  )}
                </div>
                <div>
                  <label htmlFor="email" className="mb-2 block text-sm text-white/70">
                    Email
                  </label>
                  <input
                    id="email"
                    name="email"
                    type="email"
                    autoComplete="email"
                    value={values.email}
                    onChange={onChange}
                    aria-invalid={Boolean(errors.email)}
                    aria-describedby={errors.email ? 'email-error' : undefined}
                    className={`${field} ${errors.email ? 'border-red-400/70' : 'border-white/10'}`}
                    placeholder="you@example.com"
                  />
                  {errors.email && (
                    <p id="email-error" className="mt-2 text-sm text-red-300">
                      {errors.email}
                    </p>
                  )}
                </div>
              </div>

              <div className="mt-5">
                <label htmlFor="message" className="mb-2 block text-sm text-white/70">
                  Message
                </label>
                <textarea
                  id="message"
                  name="message"
                  rows={6}
                  value={values.message}
                  onChange={onChange}
                  aria-invalid={Boolean(errors.message)}
                  aria-describedby={errors.message ? 'message-error' : undefined}
                  className={`${field} resize-y ${errors.message ? 'border-red-400/70' : 'border-white/10'}`}
                  placeholder="What would you like to talk about?"
                />
                {errors.message && (
                  <p id="message-error" className="mt-2 text-sm text-red-300">
                    {errors.message}
                  </p>
                )}
              </div>

              {/* Honeypot: hidden from people, tempting to bots */}
              <div className="absolute -left-[9999px] h-0 w-0 overflow-hidden" aria-hidden="true">
                <label htmlFor="company">Company</label>
                <input
                  id="company"
                  name="company"
                  type="text"
                  tabIndex={-1}
                  autoComplete="off"
                  value={values.company}
                  onChange={onChange}
                />
              </div>

              <div className="mt-6 flex flex-wrap items-center gap-5">
                <Magnetic>
                  <button
                    type="submit"
                    disabled={status.state === 'sending'}
                    className="btn btn-primary disabled:cursor-wait disabled:opacity-70"
                  >
                    {status.state === 'sending' ? 'Sending…' : 'Send message'}
                    <Send size={17} aria-hidden="true" />
                  </button>
                </Magnetic>

                <p
                  role="status"
                  aria-live="polite"
                  className={`flex items-start gap-2 text-sm ${
                    status.state === 'success'
                      ? 'text-emerald-300'
                      : status.state === 'error'
                        ? 'text-red-300'
                        : 'text-transparent'
                  }`}
                >
                  {status.state === 'success' && <CheckCircle2 size={18} className="mt-0.5 shrink-0" aria-hidden="true" />}
                  {status.state === 'error' && <AlertCircle size={18} className="mt-0.5 shrink-0" aria-hidden="true" />}
                  {status.message}
                </p>
              </div>
            </form>
          </FadeIn>
        </div>
      </div>
    </section>
  )
}
