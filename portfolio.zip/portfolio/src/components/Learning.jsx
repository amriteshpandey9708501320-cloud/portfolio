import { Award, BookOpen, CheckCircle2, FlaskConical, Presentation } from 'lucide-react'
import { learning } from '../data/site'
import { FadeIn, SectionHeading } from './Reveal'

const TYPE_ICON = { Workshop: Presentation, 'Online course': BookOpen, 'Self-directed': FlaskConical }

const trackPointer = (e) => {
  const r = e.currentTarget.getBoundingClientRect()
  e.currentTarget.style.setProperty('--mx', `${e.clientX - r.left}px`)
  e.currentTarget.style.setProperty('--my', `${e.clientY - r.top}px`)
}

// Opens the lightbox in <Certificates /> (listens for this event)
const openCertificate = (id) => window.dispatchEvent(new CustomEvent('open-certificate', { detail: id }))

export default function Learning() {
  return (
    <section id="learning" aria-label="Workshops and learning" className="section">
      <div className="container-x">
        <SectionHeading
          index="04"
          label="Workshops & learning"
          title="Learning by doing, not just watching."
          description="Courses, workshops and hands-on practice that are shaping how I think about software."
        />

        <ul className="grid gap-6 lg:grid-cols-3">
          {learning.map((item, i) => {
            const Icon = TYPE_ICON[item.type] || BookOpen
            return (
              <FadeIn as="li" key={item.id} delay={i * 0.08}>
                <article
                  onPointerMove={trackPointer}
                  className="glass spotlight flex h-full flex-col rounded-3xl p-7"
                >
                  <div className="flex items-center justify-between">
                    <span className="grid size-12 place-items-center rounded-2xl border border-white/10 bg-electric/10 text-electric">
                      <Icon size={22} aria-hidden="true" />
                    </span>
                    <span className="inline-flex items-center gap-1.5 rounded-full border border-white/10 px-3 py-1 font-mono text-[0.68rem] uppercase tracking-wider text-white/65">
                      {item.status === 'Completed' && (
                        <CheckCircle2 size={13} className="text-emerald-400" aria-hidden="true" />
                      )}
                      {item.status}
                    </span>
                  </div>

                  <p className="eyebrow mt-6 !text-white/45">
                    {item.type} · {item.date}
                  </p>
                  <h3 className="mt-2 text-xl font-semibold leading-snug text-white">{item.title}</h3>
                  <p className="mt-1 text-sm text-electric/90">{item.org}</p>
                  <p className="mt-4 text-sm leading-relaxed text-white/60">{item.description}</p>

                  {item.points.length > 0 && (
                    <ul className="mt-5 space-y-2 text-sm text-white/75">
                      {item.points.map((p) => (
                        <li key={p} className="flex gap-2.5">
                          <span className="mt-2 size-1.5 shrink-0 rounded-full bg-electric" aria-hidden="true" />
                          {p}
                        </li>
                      ))}
                    </ul>
                  )}

                  {item.cert && (
                    <div className="mt-auto pt-7">
                      <button
                        type="button"
                        onClick={() => openCertificate(item.cert)}
                        className="btn btn-ghost !px-4 !py-2.5 !text-sm"
                      >
                        <Award size={16} aria-hidden="true" />
                        View certificate
                      </button>
                    </div>
                  )}
                </article>
              </FadeIn>
            )
          })}
        </ul>
      </div>
    </section>
  )
}
