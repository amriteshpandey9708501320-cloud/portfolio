import { Component } from 'react'

/**
 * Catches render errors so one broken piece never blanks the whole page.
 *  - <ErrorBoundary fallback={null}> silently drops optional features (e.g. the 3D background)
 *  - <ErrorBoundary> with no fallback shows a friendly full-page message
 */
export default class ErrorBoundary extends Component {
  state = { failed: false }

  static getDerivedStateFromError() {
    return { failed: true }
  }

  componentDidCatch(error) {
    console.error('[portfolio] component error:', error)
  }

  render() {
    if (!this.state.failed) return this.props.children
    if ('fallback' in this.props) return this.props.fallback
    return (
      <div className="grid min-h-screen place-items-center bg-[#04050b] p-8 text-center text-slate-300">
        <div>
          <h1 className="mb-3 text-2xl font-semibold text-white">Something went wrong</h1>
          <p className="mb-6 text-slate-400">Please refresh the page to try again.</p>
          <button
            type="button"
            className="btn btn-primary"
            onClick={() => window.location.reload()}
          >
            Reload
          </button>
        </div>
      </div>
    )
  }
}
