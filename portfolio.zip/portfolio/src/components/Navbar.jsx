import { useEffect, useRef, useState } from 'react'
import { AnimatePresence, motion } from 'motion/react'
import { Menu, X } from 'lucide-react'
import { site } from '../data/site'
import { lockScroll, scrollToId, unlockScroll } from '../lib/scroll'

export default function Navbar({ ready }) {
  const [active, setActive] = useState('home')
  const [scrolled, setScrolled] = useState(false)
  const [open, setOpen] = useState(false)
  const firstLinkRef = useRef(null)
  const toggleRef = useRef(null)

  // Highlight the section currently in view
  useEffect(() => {
    const ids = ['home', ...site.nav.map((n) => n.id)]
    const els = ids.map((id) => document.getElementById(id)).filter(Boolean)
    const io = new IntersectionObserver(
      (entries) => {
        entries.forEach((en) => {
          if (en.isIntersecting) setActive(en.target.id)
        })
      },
      { rootMargin: '-40% 0px -55% 0px' },
    )
    els.forEach((el) => io.observe(el))
    return () => io.disconnect()
  }, [])

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24)
    onScroll()
    window.addEventListener('scroll', onScroll, { passive: true })
    return () => window.removeEventListener('scroll', onScroll)
  }, [])

  // Mobile menu: lock scroll, close on Escape, move focus in/out
  useEffect(() => {
    if (!open) return
    lockScroll()
    firstLinkRef.current?.focus()
    const onKey = (e) => {
      if (e.key === 'Escape') setOpen(false)
    }
    window.addEventListener('keydown', onKey)
    const toggle = toggleRef.current
    return () => {
      window.removeEventListener('keydown', onKey)
      unlockScroll()
      toggle?.focus()
    }
  }, [open])

  const go = (id) => (e) => {
    e.preventDefault()
    setOpen(false)
    // wait a tick so the scroll lock is released before scrolling
    setTimeout(() => scrollToId(id), open ? 60 : 0)
  }

  return (
    <>
      <motion.header
        className="fixed inset-x-0 top-0 z-50"
        initial={{ y: -80, opacity: 0 }}
        animate={ready ? { y: 0, opacity: 1 } : {}}
        transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
      >
        <div className="container-x pt-4">
          <nav
            aria-label="Primary"
            className={`flex items-center justify-between rounded-full px-4 py-2.5 transition-all duration-300 md:px-6 ${
              scrolled || open ? 'glass' : 'border border-transparent'
            }`}
          >
            <a
              href="#home"
              onClick={go('home')}
              aria-label="Amritesh Kumar Pandey, back to top"
              className="font-display text-xl font-semibold tracking-tight text-white"
            >
              <span className="text-gradient">AP</span>
              <span className="text-white/90">.</span>
            </a>

            <ul className="hidden items-center gap-1 lg:flex">
              {site.nav.map((item) => (
                <li key={item.id}>
                  <a
                    href={`#${item.id}`}
                    onClick={go(item.id)}
                    aria-current={active === item.id ? 'true' : undefined}
                    className={`relative rounded-full px-3.5 py-2 text-sm transition-colors ${
                      active === item.id ? 'text-white' : 'text-white/55 hover:text-white'
                    }`}
                  >
                    {active === item.id && (
                      <motion.span
                        layoutId="nav-pill"
                        className="absolute inset-0 -z-10 rounded-full bg-white/10"
                        transition={{ type: 'spring', stiffness: 400, damping: 34 }}
                      />
                    )}
                    {item.label}
                  </a>
                </li>
              ))}
            </ul>

            <button
              ref={toggleRef}
              type="button"
              className="grid size-10 place-items-center rounded-full text-white lg:hidden"
              aria-label={open ? 'Close menu' : 'Open menu'}
              aria-expanded={open}
              aria-controls="mobile-menu"
              onClick={() => setOpen((v) => !v)}
            >
              {open ? <X size={22} aria-hidden="true" /> : <Menu size={22} aria-hidden="true" />}
            </button>
          </nav>
        </div>
      </motion.header>

      <AnimatePresence>
        {open && (
          <motion.div
            id="mobile-menu"
            className="fixed inset-0 z-40 bg-[#04050b]/95 backdrop-blur-xl lg:hidden"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.25 }}
          >
            <ul className="container-x flex h-full flex-col justify-center gap-1 pt-16">
              {site.nav.map((item, i) => (
                <motion.li
                  key={item.id}
                  initial={{ opacity: 0, y: 24 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.05 + i * 0.05, duration: 0.5, ease: [0.16, 1, 0.3, 1] }}
                >
                  <a
                    ref={i === 0 ? firstLinkRef : undefined}
                    href={`#${item.id}`}
                    onClick={go(item.id)}
                    className={`block py-2.5 font-display text-4xl font-semibold tracking-tight ${
                      active === item.id ? 'text-gradient' : 'text-white/80'
                    }`}
                  >
                    {item.label}
                  </a>
                </motion.li>
              ))}
            </ul>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  )
}
