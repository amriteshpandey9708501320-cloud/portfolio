/**
 * ─────────────────────────────────────────────────────────────
 *  EDIT THIS FILE to update the whole portfolio.
 *  Everything below comes from details you provided. Nothing is invented.
 *
 *  TO DO before you deploy (search this file for "SET ME"):
 *   1. email, github, linkedin  → your real links
 *   2. contactForm              → see README.md ("Contact form")
 *   3. projects                 → replace the labelled examples with real work
 *   4. public/Amritesh_Kumar_Pandey_Resume.pdf → replace with your own resume
 * ─────────────────────────────────────────────────────────────
 */

export const site = {
  name: 'Amritesh Kumar Pandey',
  firstName: 'Amritesh',
  headline: 'Building Ideas Into Digital Experiences.',
  // Words of the headline (0-based index) from which the gradient starts
  headlineHighlightFrom: 3,
  subtitle: 'Computer Science Engineering Student | Aspiring Software Developer.',
  intro:
    "I'm a Computer Science Engineering student at Shree Eshwar College of Engineering, Coimbatore. I'm learning to turn ideas into clean, working software, one project, one course and one experiment at a time.",
  location: 'Coimbatore, India',
  college: 'Shree Eshwar College of Engineering',

  // ── Contact & social (SET ME) ────────────────────────────────
  email: '', // e.g. 'you@example.com'
  github: '', // e.g. 'https://github.com/your-username'
  linkedin: '', // e.g. 'https://www.linkedin.com/in/your-handle'

  // File lives in /public. Replace it with your own resume (keep the file name, or change it here).
  resume: '/Amritesh_Kumar_Pandey_Resume.pdf',

  // Contact form backend (SET ME). Fill in ONE of these. See README.md.
  contactForm: {
    web3formsKey: '', // free access key from https://web3forms.com
    formspreeEndpoint: '', // e.g. 'https://formspree.io/f/xxxxxxx'
  },

  nav: [
    { id: 'about', label: 'About' },
    { id: 'skills', label: 'Skills' },
    { id: 'projects', label: 'Projects' },
    { id: 'learning', label: 'Learning' },
    { id: 'certificates', label: 'Certificates' },
    { id: 'education', label: 'Education' },
    { id: 'contact', label: 'Contact' },
  ],
}

export const about = {
  paragraphs: [
    "I'm studying Computer Science Engineering at Shree Eshwar College of Engineering in Coimbatore, India. What pulled me toward the field is simple: I like building things that work, and I like understanding why they work.",
    'So far my foundation is HTML, CSS, JavaScript and C++. In November 2026 I completed a 30.5-hour C++ course on Udemy and a hands-on AI Tools & Claude workshop by be10x. Now I am spending time on Git and GitHub, Linux and the everyday habits of software development.',
    "I'm early in the journey, and I'd rather be honest about that than overstate it. My goal is to grow into a software engineer who writes clear, reliable code, understands the fundamentals and keeps learning, starting with real projects I can show here.",
  ],
  interests: [
    'Artificial Intelligence',
    'Web Development',
    'Software Engineering',
    'Linux',
    'Modern Technology',
  ],
  journey: [
    {
      step: '01',
      title: 'Foundations',
      text: 'HTML, CSS, JavaScript and C++: the building blocks.',
    },
    {
      step: '02',
      title: 'Practice',
      text: 'Courses, workshops and hands-on experiments with AI tools.',
    },
    {
      step: '03',
      title: 'Next',
      text: 'Git & GitHub, Linux, and my first real projects.',
    },
  ],
  ambition:
    'Become a software engineer who ships reliable, thoughtful products, and never stops learning the fundamentals.',
}

// Core skills. `icon` is a key used in components/Skills.jsx
export const skills = [
  {
    id: 'html',
    name: 'HTML',
    icon: 'Code',
    status: 'Practicing',
    blurb: 'Structuring web pages with clean, meaningful markup.',
    points: ['Page structure and semantics', 'Forms, links and media', 'The skeleton of every web project'],
  },
  {
    id: 'css',
    name: 'CSS',
    icon: 'Palette',
    status: 'Practicing',
    blurb: 'Styling pages and shaping layouts that adapt to any screen.',
    points: ['Layout and spacing', 'Responsive thinking', 'Colour, type and polish'],
  },
  {
    id: 'javascript',
    name: 'JavaScript',
    icon: 'Braces',
    status: 'Practicing',
    blurb: 'Adding behaviour and interactivity to the web.',
    points: ['Logic and functions', 'Responding to user events', 'Moving toward small web apps'],
  },
  {
    id: 'cpp',
    name: 'C++',
    icon: 'Cpu',
    status: 'Course completed',
    blurb: 'Programming fundamentals and problem-solving in C++.',
    points: [
      'Completed a 30.5-hour Udemy course (Nov 2026)',
      'Core language concepts',
      'Groundwork for data structures & algorithms',
    ],
  },
]

// Things currently being learned (shown separately from core skills)
export const learningAreas = [
  {
    id: 'ai',
    name: 'AI tools',
    icon: 'Sparkles',
    status: 'Exploring',
    text: 'Exploring how modern AI tools speed up writing, analysis and coding, and where human judgement still matters.',
  },
  {
    id: 'linux',
    name: 'Linux',
    icon: 'Terminal',
    status: 'Learning',
    text: 'Getting comfortable with the terminal and the Linux way of working.',
  },
  {
    id: 'git',
    name: 'Git & GitHub',
    icon: 'GitBranch',
    status: 'Learning',
    text: 'Learning version control to track changes and collaborate on code.',
  },
  {
    id: 'software',
    name: 'Software development',
    icon: 'Layers',
    status: 'Learning',
    text: 'Understanding how real software is planned, built, tested and shipped.',
  },
]

/**
 * PROJECTS (SET ME)
 * The three entries below are clearly-labelled EXAMPLES (isExample: true) that show the card format.
 * Replace them with your real projects. For each real project set:
 *   isExample: false, github: 'https://github.com/...', live: 'https://...'
 * Add a screenshot by putting a file in /public/images and setting image: '/images/your-shot.webp'.
 * GitHub / Live buttons only appear when a URL is provided.
 */
export const projectsNote =
  "I'm currently building my first public projects. The cards below are clearly marked examples that show the format. Real work will replace them."

export const projects = [
  {
    id: 'example-landing',
    isExample: true,
    title: 'Responsive Landing Page',
    description:
      'Example card. A single-page site built with HTML, CSS and JavaScript, focused on layout, responsiveness and clean structure.',
    tech: ['HTML', 'CSS', 'JavaScript'],
    github: '',
    live: '',
    image: '',
    hue: 'blue',
  },
  {
    id: 'example-todo',
    isExample: true,
    title: 'Interactive To-Do App',
    description:
      'Example card. A small browser app to practise DOM events, state and saving data, the kind of project that turns concepts into skills.',
    tech: ['JavaScript', 'HTML', 'CSS'],
    github: '',
    live: '',
    image: '',
    hue: 'violet',
  },
  {
    id: 'example-cpp',
    isExample: true,
    title: 'C++ Console Utility',
    description:
      'Example card. A command-line program in C++ to apply fundamentals: input handling, control flow and organising code into functions.',
    tech: ['C++'],
    github: '',
    live: '',
    image: '',
    hue: 'cyan',
  },
]

// Workshops, courses and hands-on learning
export const learning = [
  {
    id: 'be10x',
    type: 'Workshop',
    title: 'AI Tools & Claude Workshop',
    org: 'be10x',
    date: 'Nov 22, 2026',
    status: 'Completed',
    description:
      'A hands-on workshop on using AI tools for everyday technical and productivity work.',
    points: [
      'Creating presentations with AI',
      'Analysing data with AI',
      'Coding and debugging with AI',
    ],
    cert: 'be10x-ai-tools',
  },
  {
    id: 'udemy-cpp',
    type: 'Online course',
    title: 'Learn C++ Programming: Beginner to Advance',
    org: 'Udemy · Instructor: Abdul Bari',
    date: 'Nov 16, 2026',
    status: 'Completed',
    description: 'A 30.5-hour deep dive into C++, from the basics onward.',
    points: ['30.5 hours of structured learning', 'Certificate of completion'],
    cert: 'udemy-cpp',
  },
  {
    id: 'practice',
    type: 'Self-directed',
    title: 'Hands-on experimentation',
    org: 'Ongoing',
    date: 'Ongoing',
    status: 'In progress',
    description:
      'Exploring AI tools, Linux and Git by actually using them: trying things, hitting errors and learning from them.',
    points: [],
    cert: null,
  },
]

// Certificates. Images live in /public/images (optimised WebP).
export const certificates = [
  {
    id: 'be10x-ai-tools',
    title: 'AI Tools & Claude Workshop',
    issuer: 'be10x',
    date: 'November 22, 2026',
    summary: 'Certificate of completion',
    thumb: '/images/cert-be10x-540.webp',
    full: '/images/cert-be10x-1080.webp',
    width: 1080,
    height: 732,
    verifyUrl: '',
  },
  {
    id: 'udemy-cpp',
    title: 'Learn C++ Programming: Beginner to Advance, Deep Dive in C++',
    issuer: 'Udemy',
    date: 'November 16, 2026',
    summary: '30.5 total hours · Instructor: Abdul Bari',
    thumb: '/images/cert-udemy-540.webp',
    full: '/images/cert-udemy-1080.webp',
    width: 1080,
    height: 818,
    verifyUrl: '',
  },
]

// Academic & learning journey (animated timeline).
// Add your school / earlier education here when you want to: { period, title, org, text }
export const education = [
  {
    id: 'college',
    period: 'Ongoing',
    title: 'Computer Science Engineering',
    org: 'Shree Eshwar College of Engineering · Coimbatore, India',
    text: 'Studying the fundamentals of computing and software while building skills alongside the curriculum.',
    state: 'current',
  },
  {
    id: 'cpp',
    period: 'Nov 16, 2026',
    title: 'Completed C++ Programming course',
    org: 'Udemy · 30.5 hours',
    text: 'Finished a structured deep dive into C++.',
    state: 'done',
  },
  {
    id: 'workshop',
    period: 'Nov 22, 2026',
    title: 'AI Tools & Claude Workshop',
    org: 'be10x',
    text: 'Hands-on practice using AI tools to create, analyse and code.',
    state: 'done',
  },
  {
    id: 'next',
    period: 'Next',
    title: 'Git & GitHub, Linux and first projects',
    org: 'In progress',
    text: 'Turning what I have learned into real, shareable projects.',
    state: 'upcoming',
  },
]
