import { lazy, Suspense, useCallback, useEffect, useState } from 'react'
import { AnimatePresence, useReducedMotion } from 'motion/react'
import Lenis from 'lenis'

import { gsap, ScrollTrigger } from './lib/gsap'
import { scrollToId, setLenis } from './lib/scroll'
import { useMedia } from './hooks/useMedia'

import ErrorBoundary from './components/ErrorBoundary'
import Loader from './components/Loader'
import Cursor from './components/Cursor'
import ScrollProgress from './components/ScrollProgress'
import Navbar from './components/Navbar'
import BackToTop from './components/BackToTop'
import Hero from './components/Hero'
import About from './components/About'
import Skills from './components/Skills'
import Projects from './components/Projects'
import Learning from './components/Learning'
import Certificates from './components/Certificates'
import Education from './components/Education'
import Contact from './components/Contact'
import Footer from './components/Footer'

// three.js is only downloaded when it will actually be shown
const ParticleScene = lazy(() => import('./components/ParticleScene'))

export default function App() {
  const reduced = !!useReducedMotion()
  const [ready, setReady] = useState(false)
  const onLoaded = useCallback(() => setReady(true), [])

  const isDesktop = useMedia('(min-width: 1024px)')
  const hasFinePointer = useMedia('(hover: hover) and (pointer: fine)')
  const saveData = typeof navigator !== 'undefined' && navigator.connection?.saveData === true

  // Expensive 3D only on desktop-class screens, never with reduced motion / data saver
  const show3D = isDesktop && !reduced && !saveData
  const showCursor = hasFinePointer && !reduced

  // Block scrolling while the loading screen is up
  useEffect(() => {
    const root = document.documentElement
    root.classList.toggle('is-loading', !ready)
    return () => root.classList.remove('is-loading')
  }, [ready])

  // Lenis smooth scrolling, driven by GSAP's ticker so ScrollTrigger stays in sync
  useEffect(() => {
    if (reduced) return
    const lenis = new Lenis({ duration: 1.15, smoothWheel: true })
    setLenis(lenis)
    lenis.on('scroll', ScrollTrigger.update)
    const tick = (time) => lenis.raf(time * 1000)
    gsap.ticker.add(tick)
    gsap.ticker.lagSmoothing(0)
    return () => {
      gsap.ticker.remove(tick)
      lenis.destroy()
      setLenis(null)
    }
  }, [reduced])

  // Once the loader is gone, honour a #section in the URL
  useEffect(() => {
    if (!ready) return
    const id = window.location.hash.slice(1)
    if (id) setTimeout(() => scrollToId(id, true), 80)
    ScrollTrigger.refresh()
  }, [ready])

  return (
    <>
      <a href="#main" className="skip-link">
        Skip to content
      </a>

      <AnimatePresence>{!ready && <Loader onDone={onLoaded} />}</AnimatePresence>

      <div className="ambient" aria-hidden="true" />
      {show3D && (
        <ErrorBoundary fallback={null}>
          <Suspense fallback={null}>
            <ParticleScene />
          </Suspense>
        </ErrorBoundary>
      )}
      {showCursor && <Cursor />}

      <ScrollProgress />
      <Navbar ready={ready} />

      <main id="main" tabIndex={-1} className="relative z-10 outline-none">
        <Hero ready={ready} />
        <About />
        <Skills />
        <Projects />
        <Learning />
        <Certificates />
        <Education />
        <Contact />
      </main>

      <Footer />
      <BackToTop />
    </>
  )
}
